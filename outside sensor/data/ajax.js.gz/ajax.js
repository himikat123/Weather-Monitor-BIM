function ajax(url,opts){
	var req;
	if(window.XMLHttpRequest) req=new XMLHttpRequest();
	else req=new ActiveXObject("Microsoft.XMLHTTP");
	req.onreadystatechange=function(){
		if(req.readyState==4){
			if(/^2/.test(req.status) && opts.success) opts.success(req);
			else if(/^5/.test(req.status) && opts.fail) opts.fail(req);
			else if(opts.other) opts.other(req);
		}
	};
	req.open(opts.method||'POST',url,true);
	req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	req.send(opts.data);
}