# BH1750FVI
Digital Light Sensor

Very simple and minimalistic driver for the BH1750FVI Digital Light Sensor.
The included example shows how to use and connect the BH1750FVI to a ESP8266.

For Arduino IDE users:
Just download as .ZIP and add as .ZIP library (Sketch->Include Library->Add .ZIP Library).
