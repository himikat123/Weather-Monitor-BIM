var annotated_dup =
[
    [ "MD_DS3231", "class_m_d___d_s3231.html", "class_m_d___d_s3231" ]
];