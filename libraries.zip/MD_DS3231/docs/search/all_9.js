var searchData=
[
  ['pm',['pm',['../class_m_d___d_s3231.html#a2a3eaa21b17145471dfc6e54ca3b88d3',1,'MD_DS3231']]]
];
