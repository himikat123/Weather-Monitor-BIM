var searchData=
[
  ['dd',['dd',['../class_m_d___d_s3231.html#a8c049313a57a06e33dfe4725854595a0',1,'MD_DS3231']]],
  ['dow',['dow',['../class_m_d___d_s3231.html#a6d76ae22af72aedf7debc01a9d844505',1,'MD_DS3231']]]
];
