var searchData=
[
  ['almtype_5ft',['almType_t',['../_m_d___d_s3231_8h.html#ad3a3a448e61d278a8b729c41aa05088f',1,'MD_DS3231.h']]],
  ['arduino_20ds3231_20library',['Arduino DS3231 Library',['../index.html',1,'']]]
];
