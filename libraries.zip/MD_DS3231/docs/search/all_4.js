var searchData=
[
  ['getalarm1type',['getAlarm1Type',['../class_m_d___d_s3231.html#a5336cabaf8c7a255aabeb3546a62ffc7',1,'MD_DS3231']]],
  ['getalarm2type',['getAlarm2Type',['../class_m_d___d_s3231.html#a9ddee0da49d6968628a6394150bda84f',1,'MD_DS3231']]],
  ['getcentury',['getCentury',['../class_m_d___d_s3231.html#a1adb7f9ca43d7411f07d20038913ee84',1,'MD_DS3231']]]
];
