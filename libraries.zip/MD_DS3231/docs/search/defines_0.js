var searchData=
[
  ['ds3231_5fram_5fmax',['DS3231_RAM_MAX',['../_m_d___d_s3231_8h.html#a3d34a91e1e11692a21b7434618c31f41',1,'MD_DS3231.h']]]
];
