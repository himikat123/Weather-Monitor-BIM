var searchData=
[
  ['now',['now',['../class_m_d___d_s3231.html#ab17aafb279fd8c93512151b52d04ddf0',1,'MD_DS3231']]]
];
