This is an Arduino library for the BMP085/BMP180 Barometric Pressure + Temp sensor

This library was, at one point, cloned from Adafruit's BMP085 (see
OLD_README.txt).  The reason for our own fork was because we like strict
code formatting.  And over time we did some small improvements.  Having our
own repo makes it easier to do these things.
