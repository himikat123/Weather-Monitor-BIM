DS3231
======

Library to communicate with Maxim's DS3231 high-precision real-time clock (RTC)

Eric Ayars DS3231 library with JeeLabs/Ladyada's RTC libraries spliced in by 
Andy Wickert

Released into the public domain by Jeelabs, Ladyada, and Eric Ayars; public 
domain release maintained by Andy Wickert, as his changes were mostly minor: 
splicing the libraries, Arduino 1.0 compatibility for Eric's DS3231 library, 
and adding an example or two.

15 May 2011 (text but not code updated on 11 September 2013)
